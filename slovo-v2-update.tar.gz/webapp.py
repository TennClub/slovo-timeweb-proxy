"""HTTP API and static frontend for the Slovo Telegram Mini App."""
from __future__ import annotations

import hashlib
import hmac
import json
import math
import os
import re
import secrets
import time
import unicodedata
from difflib import SequenceMatcher
from pathlib import Path
from typing import Literal
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qsl, quote
from urllib.request import Request, urlopen

from dotenv import load_dotenv
from fastapi import Depends, FastAPI, Header, HTTPException, Query
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from slovo import DB, LANGUAGES

load_dotenv()
BASE_DIR = Path(__file__).resolve().parent
WEB_DIR = BASE_DIR / "web"
db = DB(os.getenv("DATABASE_PATH", "data/slovo.db"))
app = FastAPI(title="Slovo Mini App", docs_url=None, redoc_url=None)


class TelegramUser(BaseModel):
    id: int
    first_name: str = ""
    last_name: str = ""
    username: str | None = None
    language_code: str | None = None

    @property
    def display_name(self) -> str:
        return " ".join(x for x in (self.first_name, self.last_name) if x).strip() or self.username or str(self.id)


def validate_init_data(raw: str, token: str, max_age: int = 86400) -> TelegramUser:
    """Validate Telegram.WebApp.initData using Telegram's HMAC algorithm."""
    try:
        values = dict(parse_qsl(raw, keep_blank_values=True))
        received_hash = values.pop("hash")
        auth_date = int(values.get("auth_date", "0"))
    except (KeyError, TypeError, ValueError) as exc:
        raise HTTPException(401, "Invalid Telegram authorization data") from exc
    if abs(int(time.time()) - auth_date) > max_age:
        raise HTTPException(401, "Telegram authorization data has expired")
    check_string = "\n".join(f"{key}={values[key]}" for key in sorted(values))
    secret = hmac.new(b"WebAppData", token.encode(), hashlib.sha256).digest()
    expected = hmac.new(secret, check_string.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, received_hash):
        raise HTTPException(401, "Telegram signature is invalid")
    try:
        return TelegramUser.model_validate_json(values["user"])
    except (KeyError, ValueError) as exc:
        raise HTTPException(401, "Telegram user is missing") from exc


def current_user(x_telegram_init_data: str | None = Header(default=None)) -> TelegramUser:
    token = os.getenv("BOT_TOKEN", "")
    if x_telegram_init_data and token:
        user = validate_init_data(x_telegram_init_data, token)
    elif os.getenv("WEBAPP_DEV_MODE") == "1":
        user = TelegramUser(id=int(os.getenv("DEV_TELEGRAM_USER_ID", "1")), first_name=os.getenv("DEV_TELEGRAM_USER_NAME", "Demo"))
    else:
        raise HTTPException(401, "Open Slovo from Telegram")
    db.user(user.id, user.display_name)
    return user


class FolderCreate(BaseModel):
    name: str = Field(min_length=1, max_length=160)
    source_lang: str
    target_lang: str


class FolderUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=160)
    source_lang: str | None = None
    target_lang: str | None = None


class CardInput(BaseModel):
    term: str = Field(min_length=1, max_length=250)
    translation: str = Field(min_length=1, max_length=500)
    transcription: str | None = Field(default=None, max_length=250)
    example: str | None = Field(default=None, max_length=1000)
    example_translation: str | None = Field(default=None, max_length=1000)


class CardsCreate(BaseModel):
    items: list[CardInput] = Field(min_length=1, max_length=200)
    skip_duplicates: bool = True


class CardUpdate(CardInput):
    pass


class LocaleUpdate(BaseModel):
    locale: str
    timezone_offset: int = Field(default=0, ge=-840, le=840)


class InviteCreate(BaseModel):
    role: Literal["editor", "member"] = "member"


class MemberUpdate(BaseModel):
    role: Literal["editor", "member"]


class StudyCreate(BaseModel):
    folder_id: int
    mode: Literal["due", "all", "errors"] = "due"
    direction: Literal["fwd", "rev"] = "fwd"
    study_format: Literal["cards", "typing"] = "cards"
    timezone_offset: int = Field(default=0, ge=-840, le=840)


class StudyAnswer(BaseModel):
    success: bool
    card_id: int | None = None
    answer_text: str | None = Field(default=None, max_length=1000)


class StudyCheck(BaseModel):
    answer: str = Field(default="", max_length=1000)


def require_language(code: str) -> str:
    if code not in LANGUAGES:
        raise HTTPException(422, "Unsupported language")
    return code


def require_folder(user_id: int, folder_id: int):
    folder = db.folder(user_id, folder_id)
    if not folder:
        raise HTTPException(404, "Folder not found")
    return folder


def require_editor(user_id: int, folder_id: int):
    folder = require_folder(user_id, folder_id)
    if folder["role"] not in ("owner", "editor"):
        raise HTTPException(403, "Editing is not allowed")
    return folder


def require_owner(user_id: int, folder_id: int):
    folder = require_folder(user_id, folder_id)
    if folder["role"] != "owner":
        raise HTTPException(403, "Owner access required")
    return folder


def folder_json(user_id: int, folder, counts: dict | None = None) -> dict:
    word_count = int(counts["word_count"] if counts is not None else db.card_count(folder["id"]))
    due_count = int(counts["due_count"] if counts is not None else db.due_count(user_id, folder["id"]))
    learned = int(counts.get("learned_count", 0) if counts is not None else max(0, word_count - due_count))
    return {
        "id": folder["id"], "name": folder["name"], "role": folder["role"],
        "source_lang": folder["source_lang"], "target_lang": folder["target_lang"],
        "word_count": word_count, "due_count": due_count, "learned_count": learned,
        "progress_percent": round(learned * 100 / word_count) if word_count else 0,
    }


def card_json(card) -> dict:
    return {key: card[key] for key in ("id", "term", "translation", "transcription", "example", "example_translation", "audio_url")}


@app.middleware("http")
async def security_headers(request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; script-src 'self' https://telegram.org; "
        "style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; "
        "media-src 'self' https:; connect-src 'self' https://api.dictionaryapi.dev"
    )
    return response


@app.get("/health")
def health():
    return {"ok": True}


@app.get("/api/bootstrap")
def bootstrap(user: TelegramUser = Depends(current_user)):
    """Small critical-path payload; folders and profile load independently."""
    return {
        "user": {"id": user.id, "name": user.display_name, "username": user.username},
        "locale": db.locale(user.id), "languages": LANGUAGES,
    }


@app.get("/api/home")
def home(user: TelegramUser = Depends(current_user)):
    folders = [folder_json(user.id, row, dict(row)) for row in db.folder_summaries(user.id)]
    due = sum(folder["due_count"] for folder in folders)
    return {"folders": folders, "due_count": due, "estimated_minutes": math.ceil(due / 3) if due else 0}


@app.get("/api/profile")
def profile(timezone_offset: int = Query(0, ge=-840, le=840), user: TelegramUser = Depends(current_user)):
    db.set_timezone(user.id, timezone_offset)
    return {"summary": db.profile_stats(user.id), "week": db.weekly_stats(user.id, timezone_offset)}


@app.patch("/api/profile/locale")
def update_locale(body: LocaleUpdate, user: TelegramUser = Depends(current_user)):
    db.set_locale(user.id, require_language(body.locale)); db.set_timezone(user.id, body.timezone_offset)
    return {"ok": True, "locale": body.locale}


@app.post("/api/folders", status_code=201)
def create_folder(body: FolderCreate, user: TelegramUser = Depends(current_user)):
    source, target = require_language(body.source_lang), require_language(body.target_lang)
    if source == target:
        raise HTTPException(422, "Choose two different languages")
    folder_id = db.create_folder(user.id, body.name.strip(), source, target)
    return folder_json(user.id, db.folder(user.id, folder_id))


@app.get("/api/folders/{folder_id}")
def get_folder(folder_id: int, offset: int = Query(0, ge=0), limit: int = Query(50, ge=1, le=100),
               q: str = Query("", max_length=100), filter: Literal["all", "due", "errors"] = "all",
               user: TelegramUser = Depends(current_user)):
    folder = require_folder(user.id, folder_id)
    cards = db.cards(folder_id, offset, limit + 1, q.strip(), filter, user.id)
    result = folder_json(user.id, folder)
    result.update({"cards": [card_json(card) for card in cards[:limit]], "offset": offset, "has_more": len(cards) > limit,
                   "members": [dict(x) for x in db.members(folder_id)] if folder["role"] == "owner" else []})
    return result


@app.patch("/api/folders/{folder_id}")
def update_folder(folder_id: int, body: FolderUpdate, user: TelegramUser = Depends(current_user)):
    folder = require_owner(user.id, folder_id)
    if body.name is not None:
        db.rename(folder_id, body.name.strip())
    source = require_language(body.source_lang or folder["source_lang"])
    target = require_language(body.target_lang or folder["target_lang"])
    if source == target:
        raise HTTPException(422, "Choose two different languages")
    db.set_folder_languages(folder_id, source, target)
    return folder_json(user.id, db.folder(user.id, folder_id))


@app.delete("/api/folders/{folder_id}")
def delete_folder(folder_id: int, user: TelegramUser = Depends(current_user)):
    require_owner(user.id, folder_id); db.delete_folder(folder_id)
    return {"ok": True}


@app.post("/api/folders/{folder_id}/cards", status_code=201)
def create_cards(folder_id: int, body: CardsCreate, user: TelegramUser = Depends(current_user)):
    require_editor(user.id, folder_id)
    items = [(x.term.strip(), x.translation.strip(), clean_optional(x.transcription), clean_optional(x.example), clean_optional(x.example_translation)) for x in body.items]
    duplicates = [item for item in items if db.duplicate(folder_id, item[0], item[1])]
    accepted = [item for item in items if not (body.skip_duplicates and db.duplicate(folder_id, item[0], item[1]))]
    if accepted:
        db.add_cards(user.id, folder_id, accepted)
    return {"added": len(accepted), "duplicates": len(duplicates)}


def clean_optional(value: str | None) -> str | None:
    value = (value or "").strip()
    return value or None


@app.patch("/api/cards/{card_id}")
def update_card(card_id: int, body: CardUpdate, user: TelegramUser = Depends(current_user)):
    card = db.card(user.id, card_id)
    if not card:
        raise HTTPException(404, "Card not found")
    require_editor(user.id, card["folder_id"])
    values = {"term": body.term.strip(), "translation": body.translation.strip(), "transcription": clean_optional(body.transcription),
              "example": clean_optional(body.example), "example_translation": clean_optional(body.example_translation)}
    for field, value in values.items():
        db.update_card(card_id, field, value)
    return {"ok": True, "card": card_json(db.card(user.id, card_id))}


@app.delete("/api/cards/{card_id}")
def delete_card(card_id: int, user: TelegramUser = Depends(current_user)):
    card = db.card(user.id, card_id)
    if not card:
        raise HTTPException(404, "Card not found")
    require_editor(user.id, card["folder_id"]); db.delete_card(card_id)
    return {"ok": True}


def dictionary_lookup(term: str) -> tuple[str | None, str | None]:
    """Free Dictionary API lookup, used on demand and persisted on the card."""
    request = Request(f"https://api.dictionaryapi.dev/api/v2/entries/en/{quote(term)}", headers={"User-Agent": "Slovo/1.0"})
    try:
        with urlopen(request, timeout=3) as response:  # noqa: S310 - fixed HTTPS host
            data = json.load(response)
    except (HTTPError, URLError, TimeoutError, ValueError):
        return None, None
    if not isinstance(data, list) or not data:
        return None, None
    entry = data[0]; transcription = entry.get("phonetic") or None; audio = None
    for phonetic in entry.get("phonetics", []):
        transcription = transcription or phonetic.get("text") or None
        if phonetic.get("audio"):
            audio = phonetic["audio"]
            if audio.startswith("//"): audio = "https:" + audio
            break
    return transcription, audio


@app.post("/api/cards/{card_id}/pronunciation")
def pronunciation(card_id: int, user: TelegramUser = Depends(current_user)):
    card = db.card(user.id, card_id)
    if not card:
        raise HTTPException(404, "Card not found")
    folder = require_folder(user.id, card["folder_id"])
    if folder["source_lang"] != "en":
        return {"available": False, "transcription": card["transcription"], "audio_url": card["audio_url"]}
    transcription, audio = card["transcription"], card["audio_url"]
    if not transcription and not audio and re.fullmatch(r"[A-Za-z][A-Za-z '\-]{0,80}", card["term"]):
        found_transcription, found_audio = dictionary_lookup(card["term"])
        transcription, audio = found_transcription, found_audio
        if transcription: db.update_card(card_id, "transcription", transcription)
        if audio: db.update_card(card_id, "audio_url", audio)
    return {"available": bool(audio or folder["source_lang"] in LANGUAGES), "transcription": transcription, "audio_url": audio,
            "speech_lang": folder["source_lang"]}


@app.post("/api/folders/{folder_id}/invites")
def create_invite(folder_id: int, body: InviteCreate, user: TelegramUser = Depends(current_user)):
    require_owner(user.id, folder_id)
    username = os.getenv("BOT_USERNAME", "").lstrip("@")
    if not username:
        raise HTTPException(503, "BOT_USERNAME is not configured")
    token = db.create_invite(user.id, folder_id, body.role)
    return {"token": token, "url": f"https://t.me/{username}?startapp={token}", "role": body.role}


@app.get("/api/folders/{folder_id}/invites")
def list_invites(folder_id: int, user: TelegramUser = Depends(current_user)):
    require_owner(user.id, folder_id)
    username = os.getenv("BOT_USERNAME", "").lstrip("@")
    return {"items": [{**dict(row), "url": f"https://t.me/{username}?startapp={row['token']}"} for row in db.invites(folder_id)]}


@app.delete("/api/folders/{folder_id}/invites/{token}")
def revoke_invite(folder_id: int, token: str, user: TelegramUser = Depends(current_user)):
    require_owner(user.id, folder_id)
    if not db.revoke_invite(folder_id, token): raise HTTPException(404, "Invitation not found")
    return {"ok": True}


@app.post("/api/invites/{token}/join")
def join_invite(token: str, user: TelegramUser = Depends(current_user)):
    if not token.startswith("inv_") or len(token) > 80:
        raise HTTPException(404, "Invitation not found")
    folder_id = db.join(user.id, token)
    if not folder_id:
        raise HTTPException(404, "This invitation is invalid or has been revoked")
    return {"ok": True, "folder_id": folder_id}


@app.patch("/api/folders/{folder_id}/members/{member_id}")
def update_member(folder_id: int, member_id: int, body: MemberUpdate, user: TelegramUser = Depends(current_user)):
    require_owner(user.id, folder_id)
    if member_id == user.id or not db.set_member_role(folder_id, member_id, body.role):
        raise HTTPException(409, "The owner role cannot be changed")
    return {"ok": True}


@app.delete("/api/folders/{folder_id}/members/{member_id}")
def delete_member(folder_id: int, member_id: int, user: TelegramUser = Depends(current_user)):
    require_owner(user.id, folder_id)
    if member_id == user.id: raise HTTPException(409, "The owner cannot be removed")
    db.remove_member(folder_id, member_id)
    return {"ok": True}


def safe_json(value: str, fallback):
    try: return json.loads(value)
    except (TypeError, ValueError): return fallback


def session_json(user_id: int, session_id: str) -> dict:
    session = db.session(user_id, session_id)
    if not session: raise HTTPException(404, "Study session not found")
    require_folder(user_id, session["folder_id"])
    queue = safe_json(session["queue"], []); unique_ids = list(dict.fromkeys(queue)); errors = set(safe_json(session["errors"], []))
    with db.conn() as con:
        stats = con.execute("SELECT COUNT(DISTINCT card_id) unique_done,COUNT(*) attempts,SUM(first_attempt) first_correct FROM study_events WHERE session_id=?", (session_id,)).fetchone()
    total = len(unique_ids)
    if not session["current_card"]:
        duration = 0
        if session["started_at"] and session["completed_at"]:
            try: duration = max(0, round(time.mktime(time.strptime(session["completed_at"][:19], "%Y-%m-%dT%H:%M:%S"))-time.mktime(time.strptime(session["started_at"][:19], "%Y-%m-%dT%H:%M:%S"))))
            except ValueError: pass
        return {"id": session_id, "folder_id": session["folder_id"], "done": True, "total": total,
                "unique_done": stats["unique_done"] or 0, "attempts": stats["attempts"] or 0,
                "errors": len(errors), "first_correct": stats["first_correct"] or 0,
                "correct": stats["first_correct"] or 0,
                "accuracy": round((stats["first_correct"] or 0)*100/total) if total else 0,
                "duration_seconds": duration, "review_due": len(errors)}
    card = db.card(user_id, session["current_card"])
    if not card:
        db.advance(session_id); return session_json(user_id, session_id)
    folder = require_folder(user_id, session["folder_id"]); reverse = session["mode"].endswith(":rev")
    front_lang = folder["target_lang"] if reverse else folder["source_lang"]
    return {"id": session_id, "folder_id": session["folder_id"], "done": False,
            "position": (stats["unique_done"] or 0) + 1, "total": total, "attempts": stats["attempts"] or 0,
            "card_id": card["id"], "front": card["translation"] if reverse else card["term"],
            "back": card["term"] if reverse else card["translation"], "front_lang": front_lang,
            "transcription": None if reverse else card["transcription"], "audio_url": None if reverse else card["audio_url"],
            "example": card["example"], "example_translation": card["example_translation"],
            "study_format": session["study_format"], "mode": session["mode"].split(":",1)[0]}


@app.get("/api/study/unfinished")
def unfinished_study(folder_id: int, user: TelegramUser = Depends(current_user)):
    require_folder(user.id, folder_id); row = db.unfinished_session(user.id, folder_id)
    return session_json(user.id, row["id"]) if row else {"id": None}


@app.post("/api/study", status_code=201)
def create_study(body: StudyCreate, user: TelegramUser = Depends(current_user)):
    require_folder(user.id, body.folder_id); db.set_timezone(user.id, body.timezone_offset)
    mode = f"{body.mode}:{body.direction}"; card_ids = db.candidates(user.id, body.folder_id, mode)[:20]
    if not card_ids:
        return {"done": True, "total": 0, "errors": 0, "first_correct": 0, "accuracy": 0, "folder_id": body.folder_id}
    session_id = secrets.token_urlsafe(12)
    db.save_session(session_id, user.id, body.folder_id, mode, card_ids, body.study_format, body.timezone_offset)
    return session_json(user.id, session_id)


def normalize_answer(value: str) -> str:
    value = unicodedata.normalize("NFKC", value).casefold().replace("ё", "е")
    value = re.sub(r"[^\w\s'-]", " ", value, flags=re.UNICODE)
    return re.sub(r"\s+", " ", value).strip()


def answer_variants(value: str) -> list[str]:
    return [item for item in (normalize_answer(x) for x in re.split(r"[,;\n]+", value)) if item]


@app.post("/api/study/{session_id}/check")
def check_study(session_id: str, body: StudyCheck, user: TelegramUser = Depends(current_user)):
    session = db.session(user.id, session_id)
    if not session or not session["current_card"]: raise HTTPException(409, "This study session has ended")
    card = db.card(user.id, session["current_card"])
    if not card: raise HTTPException(409, "This word is no longer available")
    reverse = session["mode"].endswith(":rev"); correct = card["term"] if reverse else card["translation"]
    given = normalize_answer(body.answer); variants = answer_variants(correct)
    if not given: return {"verdict": "empty", "correct_answer": correct}
    if given in variants: return {"verdict": "correct", "correct_answer": correct}
    similarity = max((SequenceMatcher(None, given, variant).ratio() for variant in variants), default=0)
    verdict = "close" if similarity >= 0.72 else "wrong"
    return {"verdict": verdict, "correct_answer": correct, "similarity": round(similarity, 2)}


@app.post("/api/study/{session_id}/answer")
def answer_study(session_id: str, body: StudyAnswer, user: TelegramUser = Depends(current_user)):
    session = db.session(user.id, session_id)
    if not session or not session["current_card"]: raise HTTPException(409, "This study session has ended")
    if body.card_id is not None and body.card_id != session["current_card"]:
        raise HTTPException(409, "Answer already recorded")
    require_folder(user.id, session["folder_id"])
    if not db.answer(session_id, session["current_card"], body.success, session["mode"], body.answer_text):
        raise HTTPException(409, "Answer already recorded")
    db.advance(session_id)
    return session_json(user.id, session_id)


@app.post("/api/study/{session_id}/repeat-errors", status_code=201)
def repeat_errors(session_id: str, user: TelegramUser = Depends(current_user)):
    old = db.session(user.id, session_id)
    if not old: raise HTTPException(404, "Study session not found")
    errors = list(dict.fromkeys(safe_json(old["errors"], [])))[:20]
    if not errors: return {"done": True, "total": 0, "folder_id": old["folder_id"], "errors": 0, "first_correct": 0, "accuracy": 0}
    new_id = secrets.token_urlsafe(12)
    db.save_session(new_id, user.id, old["folder_id"], f"errors:{'rev' if old['mode'].endswith(':rev') else 'fwd'}", errors, old["study_format"], old["timezone_offset"])
    return session_json(user.id, new_id)


@app.get("/")
def index():
    return FileResponse(WEB_DIR / "index.html")


app.mount("/static", StaticFiles(directory=WEB_DIR), name="static")
