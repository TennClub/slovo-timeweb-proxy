import sqlite3
from pathlib import Path

from fastapi.testclient import TestClient

import webapp
from slovo import DB


def setup_app(tmp_path: Path, monkeypatch, user_id=1):
    database = DB(str(tmp_path / "upgrade.db"))
    database.user(1, "Owner")
    database.user(2, "Student")
    monkeypatch.setattr(webapp, "db", database)
    webapp.app.dependency_overrides[webapp.current_user] = lambda: webapp.TelegramUser(id=user_id, first_name="Owner" if user_id == 1 else "Student")
    return database, TestClient(webapp.app)


def test_migration_preserves_existing_cards(tmp_path):
    path = tmp_path / "legacy.db"
    con = sqlite3.connect(path)
    con.executescript("""
    CREATE TABLE users (telegram_id INTEGER PRIMARY KEY, name TEXT, last_folder_id INTEGER, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE folders (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, owner_id INTEGER NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE memberships (folder_id INTEGER,user_id INTEGER,role TEXT,PRIMARY KEY(folder_id,user_id));
    CREATE TABLE invitations (token TEXT PRIMARY KEY,folder_id INTEGER,role TEXT,created_by INTEGER,revoked INTEGER DEFAULT 0,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE cards (id INTEGER PRIMARY KEY AUTOINCREMENT,folder_id INTEGER,term TEXT NOT NULL,translation TEXT NOT NULL,created_by INTEGER NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE progress (user_id INTEGER,card_id INTEGER,level INTEGER DEFAULT 0,due_date TEXT,last_success TEXT,PRIMARY KEY(user_id,card_id));
    CREATE TABLE drafts (user_id INTEGER PRIMARY KEY,kind TEXT,payload TEXT,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE sessions (id TEXT PRIMARY KEY,user_id INTEGER,folder_id INTEGER,mode TEXT,queue TEXT,pos INTEGER DEFAULT 0,current_card INTEGER,phase TEXT DEFAULT 'ask',answered INTEGER DEFAULT 0,errors TEXT DEFAULT '',extra_counts TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    INSERT INTO users(telegram_id,name) VALUES(1,'Owner');
    INSERT INTO folders(name,owner_id) VALUES('Legacy',1);
    INSERT INTO memberships VALUES(1,1,'owner');
    INSERT INTO cards(folder_id,term,translation,created_by) VALUES(1,'apple','яблоко',1);
    """)
    con.commit(); con.close()
    database = DB(str(path))
    assert database.card(1, 1)["term"] == "apple"
    with database.conn() as migrated:
        columns = {row[1] for row in migrated.execute("PRAGMA table_info(cards)")}
        assert {"transcription", "example", "example_translation", "audio_url"} <= columns
        assert migrated.execute("PRAGMA integrity_check").fetchone()[0] == "ok"


def test_fast_home_does_not_use_per_folder_count_queries(tmp_path, monkeypatch):
    database, client = setup_app(tmp_path, monkeypatch)
    for i in range(25):
        folder = database.create_folder(1, f"Folder {i}")
        database.add_cards(1, folder, [("word", "слово")])
    monkeypatch.setattr(database, "card_count", lambda *_: (_ for _ in ()).throw(AssertionError("N+1 card count")))
    monkeypatch.setattr(database, "due_count", lambda *_: (_ for _ in ()).throw(AssertionError("N+1 due count")))
    response = client.get("/api/home")
    assert response.status_code == 200
    assert len(response.json()["folders"]) == 25
    assert response.json()["due_count"] == 25


def test_long_name_metadata_search_and_pagination(tmp_path, monkeypatch):
    database, client = setup_app(tmp_path, monkeypatch)
    name = "Cambridge Vocabulary for IELTS; Page 169, Word List"
    folder = client.post("/api/folders", json={"name": name, "source_lang": "en", "target_lang": "ru"}).json()
    items = [{"term": f"word {i}", "translation": f"перевод {i}"} for i in range(55)]
    assert client.post(f"/api/folders/{folder['id']}/cards", json={"items": items}).status_code == 201
    page = client.get(f"/api/folders/{folder['id']}?limit=50").json()
    assert page["name"] == name and len(page["cards"]) == 50 and page["has_more"]
    found = client.get(f"/api/folders/{folder['id']}?q=word%2054").json()
    assert [card["term"] for card in found["cards"]] == ["word 54"]


def test_card_transcription_examples_and_cached_audio(tmp_path, monkeypatch):
    database, client = setup_app(tmp_path, monkeypatch)
    folder = database.create_folder(1, "English", "en", "ru")
    database.add_cards(1, folder, [("apprehensive", "обеспокоенный")])
    card_id = database.cards(folder)[0]["id"]
    payload = {"term": "apprehensive", "translation": "обеспокоенный", "transcription": "/ˌæprɪˈhensɪv/",
               "example": "She felt apprehensive about the exam.", "example_translation": "Она переживала из-за экзамена."}
    updated = client.patch(f"/api/cards/{card_id}", json=payload)
    assert updated.status_code == 200 and updated.json()["card"]["example"] == payload["example"]
    database.update_card(card_id, "audio_url", "https://example.org/apprehensive.mp3")
    audio = client.post(f"/api/cards/{card_id}/pronunciation").json()
    assert audio["available"] and audio["audio_url"].endswith(".mp3")


def test_pronunciation_unavailable_for_non_english_without_audio(tmp_path, monkeypatch):
    database, client = setup_app(tmp_path, monkeypatch)
    folder = database.create_folder(1, "Spanish", "es", "ru")
    database.add_cards(1, folder, [("hola", "привет")])
    card_id = database.cards(folder)[0]["id"]
    result = client.post(f"/api/cards/{card_id}/pronunciation").json()
    assert result == {"available": False, "transcription": None, "audio_url": None}


def test_answer_normalization_variants_and_ambiguity(tmp_path, monkeypatch):
    database, client = setup_app(tmp_path, monkeypatch)
    folder = database.create_folder(1, "Words", "en", "ru")
    database.add_cards(1, folder, [("fir-tree", "ёлка, ель; ёлочка")])
    session = client.post("/api/study", json={"folder_id": folder, "mode": "all", "direction": "fwd", "study_format": "typing"}).json()
    sid = session["id"]
    assert client.post(f"/api/study/{sid}/check", json={"answer": "  ЁЛКА!!!  "}).json()["verdict"] == "correct"
    assert client.post(f"/api/study/{sid}/check", json={"answer": "елачка"}).json()["verdict"] == "close"
    assert client.post(f"/api/study/{sid}/check", json={"answer": ""}).json()["verdict"] == "empty"


def test_double_answer_unfinished_and_repeat_errors(tmp_path, monkeypatch):
    database, client = setup_app(tmp_path, monkeypatch)
    folder = database.create_folder(1, "Words")
    database.add_cards(1, folder, [("one", "один"), ("two", "два")])
    session = client.post("/api/study", json={"folder_id": folder, "mode": "all", "study_format": "cards"}).json()
    sid = session["id"]
    first_card = session["card_id"]
    first = client.post(f"/api/study/{sid}/answer", json={"success": False, "card_id": first_card})
    assert first.status_code == 200
    assert client.post(f"/api/study/{sid}/answer", json={"success": False, "card_id": first_card}).status_code == 409
    with database.conn() as con:
        assert con.execute("SELECT COUNT(*) FROM study_events WHERE session_id=?", (sid,)).fetchone()[0] == 1
    unfinished = client.get(f"/api/study/unfinished?folder_id={folder}").json()
    assert unfinished["id"] == sid
    while not first.json()["done"]:
        first = client.post(f"/api/study/{sid}/answer", json={"success": True})
    repeated = client.post(f"/api/study/{sid}/repeat-errors")
    assert repeated.status_code == 201 and repeated.json()["total"] == 1


def test_weekly_stats_definitions_and_user_independence(tmp_path, monkeypatch):
    database, client = setup_app(tmp_path, monkeypatch)
    folder = database.create_folder(1, "Shared")
    database.add_cards(1, folder, [("one", "один")])
    card_id = database.cards(folder)[0]["id"]
    token = database.create_invite(1, folder, "member")
    database.join(2, token)
    database.save_session("owner-session", 1, folder, "all:fwd", [card_id])
    database.answer("owner-session", card_id, True, "all:fwd")
    database.advance("owner-session")
    owner = database.weekly_stats(1, -180)
    student = database.weekly_stats(2, -180)
    assert owner["trainings"] == 1 and owner["unique_words"] == 1 and owner["accuracy"] == 100
    assert student["trainings"] == 0 and student["unique_words"] == 0 and student["accuracy"] == 0


def test_member_roles_invite_revoke_and_owner_protection(tmp_path, monkeypatch):
    database, client = setup_app(tmp_path, monkeypatch)
    monkeypatch.setenv("BOT_USERNAME", "LangSlovo_Bot")
    folder = database.create_folder(1, "Shared")
    invite = client.post(f"/api/folders/{folder}/invites", json={"role": "member"}).json()
    database.join(2, invite["token"])
    assert client.patch(f"/api/folders/{folder}/members/2", json={"role": "editor"}).status_code == 200
    assert database.role(2, folder) == "editor"
    assert client.patch(f"/api/folders/{folder}/members/1", json={"role": "member"}).status_code == 409
    assert client.delete(f"/api/folders/{folder}/invites/{invite['token']}").status_code == 200
    database.user(3, "Later")
    assert database.join(3, invite["token"]) is None


def test_frontend_contains_loading_error_long_name_and_keyboard_guards():
    js = Path("web/app.js").read_text()
    css = Path("web/styles.css").read_text()
    html = Path("web/index.html").read_text()
    assert "renderError" in js and "data-action=\"retry\"" in js
    assert "typingAnswer" in js and "enterkeyhint=\"done\"" in js
    assert "-webkit-line-clamp:2" in css and "-webkit-line-clamp:3" in css
    assert "Загружаем слова…" in html


def teardown_module():
    webapp.app.dependency_overrides.clear()
