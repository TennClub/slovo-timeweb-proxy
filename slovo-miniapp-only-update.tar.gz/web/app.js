const tg = window.Telegram?.WebApp;
if (tg) { tg.ready(); tg.expand(); tg.setHeaderColor('#f8f7f2'); tg.setBackgroundColor('#f8f7f2'); }

const I18N = {
  ru:{folders:'Папки',learn:'Учить',profile:'Профиль',hello:'Время учить слова',subtitle:'Общие папки, личный прогресс.',myFolders:'Мои папки',newFolder:'Новая папка',emptyFolders:'Создайте первую папку и добавьте в неё слова.',create:'Создать',cancel:'Отмена',name:'Название',source:'Язык слов',target:'Язык перевода',words:'Слова',due:'К повторению',addWords:'Добавить слова',study:'Начать учить',invite:'Пригласить',settings:'Настройки',wordList:'Список слов',noWords:'Пока нет слов.',addHint:'Каждая пара с новой строки: apple — яблоко',save:'Сохранить',added:'Слова добавлены',duplicates:'Дубли пропущены',chooseFolder:'Выберите папку',chooseDirection:'Что показывать сначала?',chooseMode:'Какие слова учить?',review:'К повторению',all:'Все слова',forward:'Прямое направление',reverse:'Обратное направление',showAnswer:'Показать ответ',know:'Знаю',dontKnow:'Не знаю',done:'Готово!',correct:'Без ошибок',mistakes:'Повторить',backFolders:'К папкам',interfaceLanguage:'Язык интерфейса',availableWords:'Доступно слов',learnedWords:'Изучено слов',sessions:'Тренировок',rename:'Переименовать',folderLanguages:'Языки папки',deleteFolder:'Удалить папку',deleteConfirm:'Удалить папку и все её слова?',member:'Только учиться',editor:'Добавлять и менять слова',inviteRole:'Права ученика',share:'Поделиться ссылкой',copied:'Ссылка скопирована',edit:'Изменить',delete:'Удалить',error:'Что-то пошло не так',openTelegram:'Откройте приложение из Telegram.',nothingDue:'На сегодня всё!',next:'Дальше',folder:'Папка'},
  en:{folders:'Folders',learn:'Learn',profile:'Profile',hello:'Time to learn words',subtitle:'Shared folders, personal progress.',myFolders:'My folders',newFolder:'New folder',emptyFolders:'Create your first folder and add words.',create:'Create',cancel:'Cancel',name:'Name',source:'Word language',target:'Translation language',words:'Words',due:'Due',addWords:'Add words',study:'Start learning',invite:'Invite',settings:'Settings',wordList:'Word list',noWords:'No words yet.',addHint:'One pair per line: apple — manzana',save:'Save',added:'Words added',duplicates:'Duplicates skipped',chooseFolder:'Choose a folder',chooseDirection:'What should appear first?',chooseMode:'Which words?',review:'Review due',all:'All words',forward:'Forward',reverse:'Reverse',showAnswer:'Show answer',know:'I know',dontKnow:"I don't know",done:'Done!',correct:'Without mistakes',mistakes:'Review',backFolders:'To folders',interfaceLanguage:'Interface language',availableWords:'Available words',learnedWords:'Learned words',sessions:'Study sessions',rename:'Rename',folderLanguages:'Folder languages',deleteFolder:'Delete folder',deleteConfirm:'Delete the folder and all its words?',member:'Study only',editor:'Add and edit words',inviteRole:'Student permissions',share:'Share link',copied:'Link copied',edit:'Edit',delete:'Delete',error:'Something went wrong',openTelegram:'Open the app from Telegram.',nothingDue:'Nothing is due today!',next:'Next',folder:'Folder'},
  es:{folders:'Carpetas',learn:'Aprender',profile:'Perfil',hello:'Hora de aprender palabras',subtitle:'Carpetas compartidas, progreso personal.',myFolders:'Mis carpetas',newFolder:'Nueva carpeta',emptyFolders:'Crea tu primera carpeta y añade palabras.',create:'Crear',cancel:'Cancelar',name:'Nombre',source:'Idioma de palabras',target:'Idioma de traducción',words:'Palabras',due:'Para repasar',addWords:'Añadir palabras',study:'Empezar',invite:'Invitar',settings:'Ajustes',wordList:'Lista de palabras',noWords:'Aún no hay palabras.',addHint:'Una pareja por línea: apple — manzana',save:'Guardar',added:'Palabras añadidas',duplicates:'Duplicados omitidos',chooseFolder:'Elige una carpeta',chooseDirection:'¿Qué mostrar primero?',chooseMode:'¿Qué palabras?',review:'Repasar pendientes',all:'Todas las palabras',forward:'Dirección normal',reverse:'Dirección inversa',showAnswer:'Mostrar respuesta',know:'Lo sé',dontKnow:'No lo sé',done:'¡Listo!',correct:'Sin errores',mistakes:'Repasar',backFolders:'A las carpetas',interfaceLanguage:'Idioma de la interfaz',availableWords:'Palabras disponibles',learnedWords:'Palabras aprendidas',sessions:'Sesiones',rename:'Renombrar',folderLanguages:'Idiomas de carpeta',deleteFolder:'Eliminar carpeta',deleteConfirm:'¿Eliminar la carpeta y todas sus palabras?',member:'Solo estudiar',editor:'Añadir y editar palabras',inviteRole:'Permisos del alumno',share:'Compartir enlace',copied:'Enlace copiado',edit:'Editar',delete:'Eliminar',error:'Algo salió mal',openTelegram:'Abre la aplicación desde Telegram.',nothingDue:'¡Nada pendiente hoy!',next:'Siguiente',folder:'Carpeta'},
  fr:{folders:'Dossiers',learn:'Apprendre',profile:'Profil',hello:'Il est temps d’apprendre',subtitle:'Dossiers partagés, progrès personnel.',myFolders:'Mes dossiers',newFolder:'Nouveau dossier',emptyFolders:'Créez votre premier dossier et ajoutez des mots.',create:'Créer',cancel:'Annuler',name:'Nom',source:'Langue des mots',target:'Langue de traduction',words:'Mots',due:'À réviser',addWords:'Ajouter des mots',study:'Commencer',invite:'Inviter',settings:'Paramètres',wordList:'Liste des mots',noWords:'Aucun mot pour le moment.',addHint:'Une paire par ligne : apple — pomme',save:'Enregistrer',added:'Mots ajoutés',duplicates:'Doublons ignorés',chooseFolder:'Choisissez un dossier',chooseDirection:'Que montrer en premier ?',chooseMode:'Quels mots ?',review:'À réviser',all:'Tous les mots',forward:'Sens normal',reverse:'Sens inverse',showAnswer:'Afficher la réponse',know:'Je sais',dontKnow:'Je ne sais pas',done:'Terminé !',correct:'Sans erreur',mistakes:'À réviser',backFolders:'Aux dossiers',interfaceLanguage:'Langue de l’interface',availableWords:'Mots disponibles',learnedWords:'Mots appris',sessions:'Sessions',rename:'Renommer',folderLanguages:'Langues du dossier',deleteFolder:'Supprimer le dossier',deleteConfirm:'Supprimer le dossier et tous ses mots ?',member:'Apprendre seulement',editor:'Ajouter et modifier',inviteRole:'Droits de l’élève',share:'Partager le lien',copied:'Lien copié',edit:'Modifier',delete:'Supprimer',error:'Une erreur est survenue',openTelegram:'Ouvrez l’application depuis Telegram.',nothingDue:'Rien à réviser aujourd’hui !',next:'Suivant',folder:'Dossier'},
  zh:{folders:'文件夹',learn:'学习',profile:'个人资料',hello:'开始学习单词',subtitle:'共享文件夹，个人进度。',myFolders:'我的文件夹',newFolder:'新建文件夹',emptyFolders:'创建第一个文件夹并添加单词。',create:'创建',cancel:'取消',name:'名称',source:'单词语言',target:'翻译语言',words:'单词',due:'待复习',addWords:'添加单词',study:'开始学习',invite:'邀请',settings:'设置',wordList:'单词列表',noWords:'暂无单词。',addHint:'每行一组：apple — 苹果',save:'保存',added:'已添加单词',duplicates:'已跳过重复项',chooseFolder:'选择文件夹',chooseDirection:'先显示哪一面？',chooseMode:'学习哪些单词？',review:'复习到期单词',all:'全部单词',forward:'正向',reverse:'反向',showAnswer:'显示答案',know:'认识',dontKnow:'不认识',done:'完成！',correct:'无错误',mistakes:'待复习',backFolders:'返回文件夹',interfaceLanguage:'界面语言',availableWords:'可用单词',learnedWords:'已学单词',sessions:'学习次数',rename:'重命名',folderLanguages:'文件夹语言',deleteFolder:'删除文件夹',deleteConfirm:'删除文件夹及其中所有单词？',member:'只能学习',editor:'添加和编辑单词',inviteRole:'学生权限',share:'分享链接',copied:'链接已复制',edit:'编辑',delete:'删除',error:'出现错误',openTelegram:'请从 Telegram 打开应用。',nothingDue:'今天没有待复习内容！',next:'下一个',folder:'文件夹'},
  ar:{folders:'المجلدات',learn:'تعلّم',profile:'الملف الشخصي',hello:'حان وقت تعلم الكلمات',subtitle:'مجلدات مشتركة وتقدم شخصي.',myFolders:'مجلداتي',newFolder:'مجلد جديد',emptyFolders:'أنشئ مجلدك الأول وأضف الكلمات.',create:'إنشاء',cancel:'إلغاء',name:'الاسم',source:'لغة الكلمات',target:'لغة الترجمة',words:'الكلمات',due:'للمراجعة',addWords:'إضافة كلمات',study:'ابدأ التعلم',invite:'دعوة',settings:'الإعدادات',wordList:'قائمة الكلمات',noWords:'لا توجد كلمات بعد.',addHint:'زوج واحد في كل سطر: apple — تفاحة',save:'حفظ',added:'تمت إضافة الكلمات',duplicates:'تم تخطي التكرارات',chooseFolder:'اختر مجلدًا',chooseDirection:'ماذا يظهر أولًا؟',chooseMode:'أي كلمات؟',review:'مراجعة المستحق',all:'كل الكلمات',forward:'الاتجاه الأمامي',reverse:'الاتجاه العكسي',showAnswer:'إظهار الإجابة',know:'أعرف',dontKnow:'لا أعرف',done:'تم!',correct:'دون أخطاء',mistakes:'للمراجعة',backFolders:'إلى المجلدات',interfaceLanguage:'لغة الواجهة',availableWords:'الكلمات المتاحة',learnedWords:'الكلمات المتعلمة',sessions:'جلسات التعلم',rename:'إعادة التسمية',folderLanguages:'لغات المجلد',deleteFolder:'حذف المجلد',deleteConfirm:'حذف المجلد وكل كلماته؟',member:'التعلم فقط',editor:'إضافة الكلمات وتعديلها',inviteRole:'صلاحيات الطالب',share:'مشاركة الرابط',copied:'تم نسخ الرابط',edit:'تعديل',delete:'حذف',error:'حدث خطأ',openTelegram:'افتح التطبيق من Telegram.',nothingDue:'لا شيء للمراجعة اليوم!',next:'التالي',folder:'مجلد'}
};

const state = {data:null, locale:'ru', view:'home', folder:null, study:null};
const content = document.querySelector('#content');
const modal = document.querySelector('#modal');
const modalContent = document.querySelector('#modalContent');
const langNames = {en:'English',ru:'Русский',es:'Español',fr:'Français',zh:'中文',ar:'العربية'};
const joinedMessages = {ru:'Папка добавлена',en:'Folder added',es:'Carpeta añadida',fr:'Dossier ajouté',zh:'文件夹已添加',ar:'تمت إضافة المجلد'};
const esc = value => String(value ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const t = key => I18N[state.locale]?.[key] || I18N.ru[key] || key;
const vibrate = type => tg?.HapticFeedback?.notificationOccurred(type);

async function api(path, options={}) {
  const response = await fetch(path, {
    ...options,
    headers:{'Content-Type':'application/json','X-Telegram-Init-Data':tg?.initData || '',...(options.headers||{})}
  });
  if (!response.ok) {
    let detail=t('error'); try { detail=(await response.json()).detail || detail; } catch {}
    throw new Error(detail);
  }
  return response.json();
}

function toast(message) {
  const el=document.querySelector('#toast'); el.textContent=message; el.hidden=false;
  clearTimeout(toast.timer); toast.timer=setTimeout(()=>el.hidden=true,2200);
}
function openModal(html) { modalContent.innerHTML=html; modal.hidden=false; document.body.style.overflow='hidden'; }
function closeModal() { modal.hidden=true; modalContent.innerHTML=''; document.body.style.overflow=''; }
function setActive(view) { document.querySelectorAll('.nav-item').forEach(x=>x.classList.toggle('active',x.dataset.action===view)); }
function applyLocale() {
  document.documentElement.lang=state.locale; document.documentElement.dir=state.locale==='ar'?'rtl':'ltr';
  document.querySelectorAll('[data-i18n]').forEach(el=>el.textContent=t(el.dataset.i18n));
}
function initials(name) { return (name||'S').split(/\s+/).slice(0,2).map(x=>x[0]).join('').toUpperCase(); }
function languageOptions(selected, exclude='') { return Object.entries(langNames).filter(([c])=>c!==exclude).map(([c,n])=>`<option value="${c}" ${c===selected?'selected':''}>${n}</option>`).join(''); }

async function refresh() { state.data=await api('/api/bootstrap'); state.locale=state.data.locale; applyLocale(); document.querySelector('#avatarButton').textContent=initials(state.data.user.name); }

function folderCard(folder) { return `<button class="folder-card" data-action="folder" data-id="${folder.id}"><span class="folder-icon">▰</span><h3>${esc(folder.name)}</h3><div class="pair">${langNames[folder.source_lang]} → ${langNames[folder.target_lang]}</div><div class="meta"><span>${folder.word_count} ${t('words').toLowerCase()}</span><span>${folder.due_count} ${t('due').toLowerCase()}</span></div></button>`; }

function renderHome() {
  state.view='home'; setActive('home'); const folders=state.data.folders;
  content.innerHTML=`<section class="hero"><p class="eyebrow">SLOVO</p><h1>${t('hello')}</h1><p>${t('subtitle')}</p></section><div class="section-head"><h2>${t('myFolders')}</h2><button class="icon-button" data-action="new-folder">+</button></div>${folders.length?`<div class="folder-grid">${folders.map(folderCard).join('')}</div>`:`<div class="empty"><div class="empty-mark">▰</div><p>${t('emptyFolders')}</p><button class="primary" data-action="new-folder">${t('newFolder')}</button></div>`}`;
}

async function renderFolder(id) {
  state.view='folder'; setActive('home'); content.innerHTML='<section class="loading"><div class="loader"></div></section>';
  const f=await api(`/api/folders/${id}?limit=200`); state.folder=f;
  const canEdit=['owner','editor'].includes(f.role); const owner=f.role==='owner';
  content.innerHTML=`<button class="back-link" data-action="home">‹ ${t('backFolders')}</button><section class="folder-header"><p class="eyebrow">${t('folder')}</p><h1>${esc(f.name)}</h1><div class="pair">${langNames[f.source_lang]} → ${langNames[f.target_lang]}</div><div class="stats"><div class="stat"><strong>${f.word_count}</strong><span>${t('words')}</span></div><div class="stat"><strong>${f.due_count}</strong><span>${t('due')}</span></div></div></section><div class="action-grid"><button class="action-card" data-action="study-setup" data-id="${f.id}"><b>◇ ${t('study')}</b><span>${t('due')}: ${f.due_count}</span></button>${canEdit?`<button class="action-card" data-action="add-words"><b>＋ ${t('addWords')}</b><span>${langNames[f.source_lang]} → ${langNames[f.target_lang]}</span></button>`:''}${owner?`<button class="action-card" data-action="invite"><b>↗ ${t('invite')}</b><span>${t('member')}</span></button><button class="action-card" data-action="folder-settings"><b>⚙ ${t('settings')}</b><span>${t('folderLanguages')}</span></button>`:''}</div><div class="section-head"><h2>${t('wordList')}</h2></div>${f.cards.length?`<div class="card-list">${f.cards.map(c=>`<div class="word-row"><div class="word-copy"><b>${esc(c.term)}</b><span>${esc(c.translation)}</span></div>${canEdit?`<button class="more-button" data-action="edit-card" data-id="${c.id}">•••</button>`:''}</div>`).join('')}</div>`:`<div class="empty"><p>${t('noWords')}</p></div>`}`;
}

function renderProfile() {
  state.view='profile';setActive('profile');const {user,profile}=state.data;
  content.innerHTML=`<section class="profile-card"><div class="profile-avatar">${initials(user.name)}</div><h1>${esc(user.name)}</h1><div class="profile-stats"><div class="stat"><strong>${profile.folders}</strong><span>${t('folders')}</span></div><div class="stat"><strong>${profile.words}</strong><span>${t('availableWords')}</span></div><div class="stat"><strong>${profile.learned}</strong><span>${t('learnedWords')}</span></div><div class="stat"><strong>${profile.sessions}</strong><span>${t('sessions')}</span></div></div></section><div class="section-head"><h2>${t('interfaceLanguage')}</h2></div><div class="language-list">${Object.entries(langNames).map(([c,n])=>`<button class="chip ${c===state.locale?'selected':''}" data-action="set-locale" data-locale="${c}">${n}</button>`).join('')}</div>`;
}

function renderLearn() {
  state.view='learn';setActive('learn');const folders=state.data.folders;
  content.innerHTML=`<div class="section-head"><h1>${t('chooseFolder')}</h1></div>${folders.length?`<div class="folder-grid">${folders.map(f=>folderCard({...f})).join('').replaceAll('data-action="folder"','data-action="study-setup"')}</div>`:`<div class="empty"><p>${t('emptyFolders')}</p><button class="primary" data-action="new-folder">${t('newFolder')}</button></div>`}`;
}

function newFolderModal() {
  openModal(`<h2>${t('newFolder')}</h2><form id="folderForm"><div class="field"><label>${t('name')}</label><input name="name" maxlength="80" required autofocus></div><div class="field"><label>${t('source')}</label><select name="source">${languageOptions('en')}</select></div><div class="field"><label>${t('target')}</label><select name="target">${languageOptions('ru')}</select></div><div class="button-row"><button type="button" class="secondary" data-action="close-modal">${t('cancel')}</button><button class="primary">${t('create')}</button></div></form>`);
  document.querySelector('#folderForm').addEventListener('submit',async e=>{e.preventDefault();const fd=new FormData(e.target);try{const f=await api('/api/folders',{method:'POST',body:JSON.stringify({name:fd.get('name'),source_lang:fd.get('source'),target_lang:fd.get('target')})});closeModal();await refresh();vibrate('success');renderFolder(f.id)}catch(err){toast(err.message)}});
}

function addWordsModal() {
  openModal(`<h2>${t('addWords')}</h2><form id="wordsForm"><div class="field"><textarea name="words" required placeholder="apple — яблоко\nbook — книга"></textarea><div class="hint">${t('addHint')}</div></div><div class="button-row"><button type="button" class="secondary" data-action="close-modal">${t('cancel')}</button><button class="primary">${t('save')}</button></div></form>`);
  document.querySelector('#wordsForm').addEventListener('submit',async e=>{e.preventDefault();const raw=new FormData(e.target).get('words');const items=raw.split(/\n/).map(x=>x.trim()).filter(Boolean).map(line=>{const p=line.includes('\t')?line.split(/\t/,2):line.split(/\s+[—–-]\s+/,2);return {term:(p[0]||'').trim(),translation:(p[1]||'').trim()}}).filter(x=>x.term&&x.translation);if(!items.length)return toast(t('addHint'));try{const result=await api(`/api/folders/${state.folder.id}/cards`,{method:'POST',body:JSON.stringify({items,skip_duplicates:true})});closeModal();toast(`${t('added')}: ${result.added}${result.duplicates?` · ${t('duplicates')}: ${result.duplicates}`:''}`);await refresh();renderFolder(state.folder.id)}catch(err){toast(err.message)}});
}

function studySetup(id) {
  const f=state.data.folders.find(x=>x.id===Number(id));if(!f)return;
  openModal(`<h2>${t('chooseDirection')}</h2><form id="studyForm"><label class="field"><input type="radio" name="direction" value="fwd" checked><b>${langNames[f.source_lang]} → ${langNames[f.target_lang]}</b></label><label class="field"><input type="radio" name="direction" value="rev"><b>${langNames[f.target_lang]} → ${langNames[f.source_lang]}</b></label><h3>${t('chooseMode')}</h3><label class="field"><input type="radio" name="mode" value="due" checked><b>${t('review')} · ${f.due_count}</b></label><label class="field"><input type="radio" name="mode" value="all"><b>${t('all')} · ${f.word_count}</b></label><div class="button-row"><button type="button" class="secondary" data-action="close-modal">${t('cancel')}</button><button class="primary">${t('study')}</button></div></form>`);
  document.querySelector('#studyForm').addEventListener('submit',async e=>{e.preventDefault();const fd=new FormData(e.target);try{state.study=await api('/api/study',{method:'POST',body:JSON.stringify({folder_id:f.id,direction:fd.get('direction'),mode:fd.get('mode')})});closeModal();renderStudy()}catch(err){toast(err.message)}});
}

function renderStudy(revealed=false) {
  state.view='study';setActive('learn');const s=state.study;
  if(s.done){content.innerHTML=`<section class="study-card"><div class="result-mark">✓</div><h1>${s.total?t('done'):t('nothingDue')}</h1>${s.total?`<div class="stats"><div class="stat"><strong>${s.correct}</strong><span>${t('correct')}</span></div><div class="stat"><strong>${s.errors}</strong><span>${t('mistakes')}</span></div></div>`:''}<div class="study-actions"><button class="primary" data-action="home">${t('backFolders')}</button></div></section>`;refresh();return;}
  const pct=Math.min(100,Math.round((s.position-1)/s.total*100));
  content.innerHTML=`<button class="back-link" data-action="learn">‹ ${t('learn')}</button><section class="study-card"><div class="progress"><i style="width:${pct}%"></i></div><p class="eyebrow">${s.position} / ${s.total}</p><h1 class="study-word">${esc(s.front)}</h1>${revealed?`<div class="study-back">${esc(s.back)}</div><div class="study-actions button-row"><button class="danger" data-answer="false">${t('dontKnow')}</button><button class="primary" data-answer="true">${t('know')}</button></div>`:`<div class="study-actions"><button class="primary" data-action="reveal">${t('showAnswer')}</button></div>`}</section>`;
}

function inviteModal() {
  openModal(`<h2>${t('invite')}</h2><form id="inviteForm"><div class="field"><label>${t('inviteRole')}</label><select name="role"><option value="member">${t('member')}</option><option value="editor">${t('editor')}</option></select></div><div class="button-row"><button type="button" class="secondary" data-action="close-modal">${t('cancel')}</button><button class="primary">${t('create')}</button></div></form>`);
  document.querySelector('#inviteForm').addEventListener('submit',async e=>{e.preventDefault();const role=new FormData(e.target).get('role');try{const x=await api(`/api/folders/${state.folder.id}/invites`,{method:'POST',body:JSON.stringify({role})});modalContent.innerHTML=`<h2>${t('invite')}</h2><div class="field"><input id="inviteUrl" value="${esc(x.url)}" readonly></div><button class="primary" data-action="share-invite" data-url="${esc(x.url)}">${t('share')}</button>`}catch(err){toast(err.message)}});
}

function settingsModal() {
  const f=state.folder;openModal(`<h2>${t('settings')}</h2><form id="settingsForm"><div class="field"><label>${t('name')}</label><input name="name" value="${esc(f.name)}" required maxlength="80"></div><div class="field"><label>${t('source')}</label><select name="source">${languageOptions(f.source_lang)}</select></div><div class="field"><label>${t('target')}</label><select name="target">${languageOptions(f.target_lang)}</select></div><button class="primary">${t('save')}</button></form><button class="danger" style="margin-top:24px" data-action="delete-folder">${t('deleteFolder')}</button>`);
  document.querySelector('#settingsForm').addEventListener('submit',async e=>{e.preventDefault();const fd=new FormData(e.target);try{await api(`/api/folders/${f.id}`,{method:'PATCH',body:JSON.stringify({name:fd.get('name'),source_lang:fd.get('source'),target_lang:fd.get('target')})});closeModal();await refresh();renderFolder(f.id)}catch(err){toast(err.message)}});
}

function editCardModal(id) {
  const card=state.folder.cards.find(x=>x.id===Number(id));if(!card)return;
  openModal(`<h2>${t('edit')}</h2><form id="cardForm"><div class="field"><label>${t('source')}</label><input name="term" value="${esc(card.term)}" required maxlength="250"></div><div class="field"><label>${t('target')}</label><input name="translation" value="${esc(card.translation)}" required maxlength="250"></div><button class="primary">${t('save')}</button></form><button class="danger" style="margin-top:18px" data-action="delete-card" data-id="${id}">${t('delete')}</button>`);
  document.querySelector('#cardForm').addEventListener('submit',async e=>{e.preventDefault();const fd=new FormData(e.target);try{await api(`/api/cards/${id}`,{method:'PATCH',body:JSON.stringify({term:fd.get('term'),translation:fd.get('translation')})});closeModal();renderFolder(state.folder.id)}catch(err){toast(err.message)}});
}

document.addEventListener('click',async e=>{
  const answer=e.target.closest('[data-answer]');if(answer){try{state.study=await api(`/api/study/${state.study.id}/answer`,{method:'POST',body:JSON.stringify({success:answer.dataset.answer==='true'})});vibrate(answer.dataset.answer==='true'?'success':'warning');renderStudy()}catch(err){toast(err.message)}return;}
  const el=e.target.closest('[data-action]');if(!el)return;const a=el.dataset.action;
  try{
    if(a==='home'){closeModal();await refresh();renderHome()}
    else if(a==='profile'){closeModal();await refresh();renderProfile()}
    else if(a==='learn'){closeModal();await refresh();renderLearn()}
    else if(a==='folder')renderFolder(el.dataset.id);
    else if(a==='new-folder')newFolderModal();
    else if(a==='close-modal')closeModal();
    else if(a==='add-words')addWordsModal();
    else if(a==='study-setup')studySetup(el.dataset.id);
    else if(a==='reveal')renderStudy(true);
    else if(a==='invite')inviteModal();
    else if(a==='folder-settings')settingsModal();
    else if(a==='edit-card')editCardModal(el.dataset.id);
    else if(a==='set-locale'){await api('/api/profile/locale',{method:'PATCH',body:JSON.stringify({locale:el.dataset.locale})});state.locale=el.dataset.locale;await refresh();renderProfile()}
    else if(a==='share-invite'){const url=el.dataset.url;if(navigator.share)await navigator.share({title:'Slovo',url});else{await navigator.clipboard.writeText(url);toast(t('copied'))}}
    else if(a==='delete-card'){if(confirm(t('delete')+'?')){await api(`/api/cards/${el.dataset.id}`,{method:'DELETE'});closeModal();renderFolder(state.folder.id)}}
    else if(a==='delete-folder'){if(confirm(t('deleteConfirm'))){const id=state.folder.id;await api(`/api/folders/${id}`,{method:'DELETE'});closeModal();await refresh();renderHome()}}
  } catch(err) { toast(err.message||t('error')); }
});

(async()=>{try{
  await refresh();
  const startParam=tg?.initDataUnsafe?.start_param || new URLSearchParams(location.search).get('tgWebAppStartParam');
  if(startParam?.startsWith('inv_')){
    try{
      const result=await api(`/api/invites/${encodeURIComponent(startParam)}/join`,{method:'POST'});
      await refresh();renderFolder(result.folder_id);toast(joinedMessages[state.locale]||joinedMessages.ru);return;
    }catch(err){toast(err.message)}
  }
  renderHome();
}catch(err){content.innerHTML=`<div class="empty"><div class="empty-mark">S</div><h2>${t('openTelegram')}</h2><p>${esc(err.message)}</p></div>`}})();
