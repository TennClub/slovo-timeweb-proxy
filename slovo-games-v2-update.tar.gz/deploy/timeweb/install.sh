#!/usr/bin/env bash
set -euo pipefail

cd /opt/slovo
mkdir -p data/backups data/avatars

if [[ -f data/slovo.db ]]; then
  BACKUP_PATH="data/backups/slovo-before-miniapp-$(date +%Y%m%d-%H%M%S).db"
  .venv/bin/python - "$BACKUP_PATH" <<'PY'
import sqlite3
import sys
source = sqlite3.connect("data/slovo.db")
target = sqlite3.connect(sys.argv[1])
with target:
    source.backup(target)
target.close()
source.close()
PY
  echo "Database backup: /opt/slovo/$BACKUP_PATH"
fi

.venv/bin/pip install -r requirements.txt
.venv/bin/python catalog_data.py
install -m 0644 deploy/timeweb/slovo-bot.service /etc/systemd/system/slovo-bot.service
install -m 0644 deploy/timeweb/slovo-web.service /etc/systemd/system/slovo-web.service

# The old service name was used by the first Slovo release.
systemctl disable --now slovo.service 2>/dev/null || true
systemctl daemon-reload
systemctl enable slovo-bot.service slovo-web.service
systemctl restart slovo-bot.service slovo-web.service

systemctl --no-pager --full status slovo-bot.service slovo-web.service
