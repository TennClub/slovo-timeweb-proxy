"""HTTP API and static frontend for the Slovo Telegram Mini App."""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import secrets
import time
from pathlib import Path
from typing import Literal
from urllib.parse import parse_qsl

from dotenv import load_dotenv
from fastapi import Depends, FastAPI, Header, HTTPException, Query
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from slovo import DB, LANGUAGES

load_dotenv()
BASE_DIR = Path(__file__).resolve().parent
WEB_DIR = BASE_DIR / "web"
db = DB(os.getenv("DATABASE_PATH", "data/slovo.db"))
app = FastAPI(title="Slovo Mini App", docs_url=None, redoc_url=None)


class TelegramUser(BaseModel):
    id: int
    first_name: str = ""
    last_name: str = ""
    username: str | None = None
    language_code: str | None = None

    @property
    def display_name(self) -> str:
        return " ".join(x for x in (self.first_name, self.last_name) if x).strip() or self.username or str(self.id)


def validate_init_data(raw: str, token: str, max_age: int = 86400) -> TelegramUser:
    """Validate Telegram.WebApp.initData using Telegram's HMAC algorithm."""
    try:
        values = dict(parse_qsl(raw, keep_blank_values=True))
        received_hash = values.pop("hash")
        auth_date = int(values.get("auth_date", "0"))
    except (KeyError, TypeError, ValueError) as exc:
        raise HTTPException(401, "Invalid Telegram authorization data") from exc
    if abs(int(time.time()) - auth_date) > max_age:
        raise HTTPException(401, "Telegram authorization data has expired")
    check_string = "\n".join(f"{key}={values[key]}" for key in sorted(values))
    secret = hmac.new(b"WebAppData", token.encode(), hashlib.sha256).digest()
    expected = hmac.new(secret, check_string.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, received_hash):
        raise HTTPException(401, "Telegram signature is invalid")
    try:
        return TelegramUser.model_validate_json(values["user"])
    except (KeyError, ValueError) as exc:
        raise HTTPException(401, "Telegram user is missing") from exc


def current_user(x_telegram_init_data: str | None = Header(default=None)) -> TelegramUser:
    token = os.getenv("BOT_TOKEN", "")
    if x_telegram_init_data and token:
        user = validate_init_data(x_telegram_init_data, token)
    elif os.getenv("WEBAPP_DEV_MODE") == "1":
        user = TelegramUser(
            id=int(os.getenv("DEV_TELEGRAM_USER_ID", "1")),
            first_name=os.getenv("DEV_TELEGRAM_USER_NAME", "Demo"),
        )
    else:
        raise HTTPException(401, "Open Slovo from Telegram")
    db.user(user.id, user.display_name)
    return user


class FolderCreate(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    source_lang: str
    target_lang: str


class FolderUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=80)
    source_lang: str | None = None
    target_lang: str | None = None


class CardInput(BaseModel):
    term: str = Field(min_length=1, max_length=250)
    translation: str = Field(min_length=1, max_length=250)


class CardsCreate(BaseModel):
    items: list[CardInput] = Field(min_length=1, max_length=200)
    skip_duplicates: bool = True


class CardUpdate(BaseModel):
    term: str = Field(min_length=1, max_length=250)
    translation: str = Field(min_length=1, max_length=250)


class LocaleUpdate(BaseModel):
    locale: str


class InviteCreate(BaseModel):
    role: Literal["editor", "member"] = "member"


class StudyCreate(BaseModel):
    folder_id: int
    mode: Literal["due", "all"] = "due"
    direction: Literal["fwd", "rev"] = "fwd"


class StudyAnswer(BaseModel):
    success: bool


def require_language(code: str) -> str:
    if code not in LANGUAGES:
        raise HTTPException(422, "Unsupported language")
    return code


def require_folder(user_id: int, folder_id: int):
    folder = db.folder(user_id, folder_id)
    if not folder:
        raise HTTPException(404, "Folder not found")
    return folder


def require_editor(user_id: int, folder_id: int):
    folder = require_folder(user_id, folder_id)
    if folder["role"] not in ("owner", "editor"):
        raise HTTPException(403, "Editing is not allowed")
    return folder


def require_owner(user_id: int, folder_id: int):
    folder = require_folder(user_id, folder_id)
    if folder["role"] != "owner":
        raise HTTPException(403, "Owner access required")
    return folder


def folder_json(user_id: int, folder) -> dict:
    return {
        "id": folder["id"], "name": folder["name"], "role": folder["role"],
        "source_lang": folder["source_lang"], "target_lang": folder["target_lang"],
        "word_count": db.card_count(folder["id"]),
        "due_count": db.due_count(user_id, folder["id"]),
    }


@app.middleware("http")
async def security_headers(request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; script-src 'self' https://telegram.org; "
        "style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; connect-src 'self'"
    )
    return response


@app.get("/health")
def health():
    return {"ok": True}


@app.get("/api/bootstrap")
def bootstrap(user: TelegramUser = Depends(current_user)):
    locale = db.locale(user.id)
    folders = [folder_json(user.id, f) for f in db.folders(user.id)]
    return {
        "user": {"id": user.id, "name": user.display_name, "username": user.username},
        "locale": locale, "languages": LANGUAGES, "folders": folders,
        "profile": db.profile_stats(user.id),
    }


@app.patch("/api/profile/locale")
def update_locale(body: LocaleUpdate, user: TelegramUser = Depends(current_user)):
    db.set_locale(user.id, require_language(body.locale))
    return {"ok": True, "locale": body.locale}


@app.post("/api/folders", status_code=201)
def create_folder(body: FolderCreate, user: TelegramUser = Depends(current_user)):
    source = require_language(body.source_lang)
    target = require_language(body.target_lang)
    if source == target:
        raise HTTPException(422, "Choose two different languages")
    folder_id = db.create_folder(user.id, body.name.strip(), source, target)
    return folder_json(user.id, db.folder(user.id, folder_id))


@app.get("/api/folders/{folder_id}")
def get_folder(folder_id: int, offset: int = Query(0, ge=0), limit: int = Query(100, ge=1, le=200), user: TelegramUser = Depends(current_user)):
    folder = require_folder(user.id, folder_id)
    with db.conn() as con:
        cards = con.execute("SELECT id,term,translation FROM cards WHERE folder_id=? ORDER BY id LIMIT ? OFFSET ?", (folder_id, limit, offset)).fetchall()
    result = folder_json(user.id, folder)
    result["cards"] = [dict(c) for c in cards]
    return result


@app.patch("/api/folders/{folder_id}")
def update_folder(folder_id: int, body: FolderUpdate, user: TelegramUser = Depends(current_user)):
    folder = require_owner(user.id, folder_id)
    if body.name is not None:
        db.rename(folder_id, body.name.strip())
    source = require_language(body.source_lang or folder["source_lang"])
    target = require_language(body.target_lang or folder["target_lang"])
    if source == target:
        raise HTTPException(422, "Choose two different languages")
    db.set_folder_languages(folder_id, source, target)
    return folder_json(user.id, db.folder(user.id, folder_id))


@app.delete("/api/folders/{folder_id}")
def delete_folder(folder_id: int, user: TelegramUser = Depends(current_user)):
    require_owner(user.id, folder_id)
    db.delete_folder(folder_id)
    return {"ok": True}


@app.post("/api/folders/{folder_id}/cards", status_code=201)
def create_cards(folder_id: int, body: CardsCreate, user: TelegramUser = Depends(current_user)):
    require_editor(user.id, folder_id)
    items = [(item.term.strip(), item.translation.strip()) for item in body.items]
    duplicates = [item for item in items if db.duplicate(folder_id, *item)]
    accepted = [item for item in items if not (body.skip_duplicates and db.duplicate(folder_id, *item))]
    if accepted:
        db.add_cards(user.id, folder_id, accepted)
    return {"added": len(accepted), "duplicates": len(duplicates)}


@app.patch("/api/cards/{card_id}")
def update_card(card_id: int, body: CardUpdate, user: TelegramUser = Depends(current_user)):
    card = db.card(user.id, card_id)
    if not card:
        raise HTTPException(404, "Card not found")
    require_editor(user.id, card["folder_id"])
    db.update_card(card_id, "term", body.term.strip())
    db.update_card(card_id, "translation", body.translation.strip())
    return {"ok": True}


@app.delete("/api/cards/{card_id}")
def delete_card(card_id: int, user: TelegramUser = Depends(current_user)):
    card = db.card(user.id, card_id)
    if not card:
        raise HTTPException(404, "Card not found")
    require_editor(user.id, card["folder_id"])
    db.delete_card(card_id)
    return {"ok": True}


@app.post("/api/folders/{folder_id}/invites")
def create_invite(folder_id: int, body: InviteCreate, user: TelegramUser = Depends(current_user)):
    require_owner(user.id, folder_id)
    username = os.getenv("BOT_USERNAME", "").lstrip("@")
    if not username:
        raise HTTPException(503, "BOT_USERNAME is not configured")
    token = db.create_invite(user.id, folder_id, body.role)
    return {"url": f"https://t.me/{username}?startapp={token}", "role": body.role}


@app.post("/api/invites/{token}/join")
def join_invite(token: str, user: TelegramUser = Depends(current_user)):
    if not token.startswith("inv_") or len(token) > 80:
        raise HTTPException(404, "Invitation not found")
    folder_id = db.join(user.id, token)
    if not folder_id:
        raise HTTPException(404, "This invitation is invalid or has been revoked")
    return {"ok": True, "folder_id": folder_id}


def session_json(user_id: int, session_id: str) -> dict:
    session = db.session(user_id, session_id)
    if not session:
        raise HTTPException(404, "Study session not found")
    queue = json.loads(session["queue"])
    errors = set(json.loads(session["errors"]))
    if not session["current_card"]:
        unique = min(10, len(set(queue)))
        return {"id": session_id, "done": True, "total": unique, "errors": len(errors), "correct": max(0, unique-len(errors))}
    card = db.card(user_id, session["current_card"])
    if not card:
        db.advance(session_id)
        return session_json(user_id, session_id)
    reverse = session["mode"].endswith(":rev")
    return {
        "id": session_id, "done": False, "position": session["pos"] + 1,
        "total": min(10, len(set(queue))), "card_id": card["id"],
        "front": card["translation"] if reverse else card["term"],
        "back": card["term"] if reverse else card["translation"],
    }


@app.post("/api/study", status_code=201)
def create_study(body: StudyCreate, user: TelegramUser = Depends(current_user)):
    require_folder(user.id, body.folder_id)
    mode = f"{body.mode}:{body.direction}"
    card_ids = db.candidates(user.id, body.folder_id, mode)[:10]
    if not card_ids:
        return {"done": True, "total": 0, "errors": 0, "correct": 0}
    session_id = secrets.token_urlsafe(9)
    db.save_session(session_id, user.id, body.folder_id, mode, card_ids)
    return session_json(user.id, session_id)


@app.post("/api/study/{session_id}/answer")
def answer_study(session_id: str, body: StudyAnswer, user: TelegramUser = Depends(current_user)):
    session = db.session(user.id, session_id)
    if not session or not session["current_card"]:
        raise HTTPException(409, "This study session has ended")
    if not db.answer(session_id, session["current_card"], body.success, session["mode"]):
        raise HTTPException(409, "Answer already recorded")
    db.advance(session_id)
    return session_json(user.id, session_id)


@app.get("/")
def index():
    return FileResponse(WEB_DIR / "index.html")


app.mount("/static", StaticFiles(directory=WEB_DIR), name="static")
